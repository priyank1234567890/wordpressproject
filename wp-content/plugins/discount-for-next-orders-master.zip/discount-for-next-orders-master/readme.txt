=== WooCommerce Discount for Next Orders ===

Contributors: moreaddons
Donate link: 
Tags: discount for next order, woocommerce coupons, offer for next order, Coupon code, discount, create coupon automatically, order completed, coupon,discount, email, Wordpress, WooCommerce, offers, upsell, cross sell
Requires at least: 3.0.1
Tested up to: 4.8
Stable tag: 1.1.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Pull your customers back for the next order on your store.

== Description ==

= Introduction =

When you want your customer to be a long lasting customer, you just need to provide a discount for their next order. By this way, you can have your customer to be everlasting. This can be done by our plugin Discount for Next Orders.

By using this plugin you can achieve a complete customer satisfaction and motive them to carry-on in their future shopping.


= Features =
* <strong>Flexible auto generates coupons based on Settings. </strong>
* <strong>Restrict by email and limit for the coupon usage. </strong>
* <strong>Customize your coupon code Name. </strong>
* <strong>Professional email template for sending coupons.</strong>
* <strong>WPML Support</strong>

= How this works? =

The main concept of this plugin is to provide DISCOUNTS to the customers by using the coupon method.

In brief, once when the order is placed by the customer, it gets processed and finally, when the order is completed an E-Mail will be sent to the respective customer.

The mail contains the "Discount Coupon Code" which will be the combination of the Random Code and User Name along with the details like, the initial date of the coupon, expiry date of the coupon. Apart from this, the e-mail button link corresponding to the particular offer page will also be included in the mail.

Once when the mail has been received by the customer, he/she can click on the e-mail button link, which leads them directly to the offer page. Later they can enter the coupon code in the provided field and avail their offer.

This is how the plugin "Discounts for Next Orders" works.

= About MoreAddons =

MoreAddons creates unique quality WordPress/WooCommerce plug-ins that are ease to use and customize.

Tag: discount for next order, woocommerce coupons, create coupon automatically, order completed, coupon,discount, email, Wordpress, WooCommerce, offers, upsell, cross sell

== Installation ==

1. Upload the plugin folder to the ‘/wp-content/plugins/’ directory.
2. Activate the plugin through the ‘Plugins’ menu in WordPress.
3. That's it – you can now configure the plugin.

== Frequently Asked Questions ==

= What is the achivement of this plugin? =

By using this plugin you can achieve a complete customer satisfaction and motive them to carry-on in their future shopping.
This helps in the business growth too.

= Is the plugin configuration complicated? =

The plugin is very easy to configure. We have a step by step tutorial on setting up this plugin. 

== Screenshots ==

1. Discount for Next Orders: Settings Page.
2. Email Template (Basic)

== Changelog ==

= 1.1.2 =
 * Minor Functionality Change.

= 1.1.1 =
 * Bug Fix.
 
= 1.1.0 =
 * Coupon code suffix option implemented.

= 1.0.4 =
 * Custom Email Sender Name option included.

= 1.0.3 =
 * Contents Updated.

= 1.0.2 =
 * Minor Bug Fixes.


= 1.0.1 =
 * Enable/Disable Option Implemented.

= 1.0.0 =
 * Initial Commit.
 
== Upgrade Notice ==

= 1.1.2 =
 * Minor Functionality Change.
